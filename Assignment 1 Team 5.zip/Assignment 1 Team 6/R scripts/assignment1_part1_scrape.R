setwd("/Users/hinagandhi/desktop/")
install.packages("rvest")
install.packages("RSelenium")
install.packages("tidyr")
install.packages("outliers")
library(rvest)
library("RSelenium")
library('httr')
library(tidyr)
url <- "https://www.ffiec.gov/nicpubweb/nicweb/HCSGreaterThan10B.aspx"
checkForServer()
# starting selenium server
startServer()
# setting driver = chrome
myBrowser <- remoteDriver(browserName="chrome")
# open the browser
myBrowser$open()
# navigate to url
myBrowser$navigate(url)
options_available <- html(x = url)
# select all drop down options
text <- options_available %>% 
  html_nodes(xpath='//*[@id="DateDropDown"]/option')%>%
  html_text() 
text
# automating selection of each option from drop down starting from option 1
option <- myBrowser$findElement(using = 'xpath', '//*[@id="DateDropDown"]/option[1]')
# clicking the option 1
option$clickElement()
# parsing the whole web page
doc <- htmlParse(myBrowser$getPageSource()[[1]])
# extracting all tables from the page
table = readHTMLTable(doc,header=TRUE,as.data.frame = TRUE)
# storing details of table 3 in temp 1 dataframe
temp1 = table[[3]]
# creating a new column of quarter 
quarter <-  rep(text[1],nrow(temp1))
# Renaming quarter name total assets to Total Assets
colnames(temp1)[4] <- 'Total Assets'
# adding quarter column to dataframe temp 1
temp1 <- cbind(temp1,quarter)
# creating 15 different dataframes for every options of drop down
option <- myBrowser$findElement(using ='xpath','//*[@id="DateDropDown"]/option[2]')
option$clickElement()
doc <- htmlParse(myBrowser$getPageSource()[[1]])
table = readHTMLTable(doc,header=TRUE,as.data.frame = TRUE)
temp2 = table[[3]]
quarter <-  rep(text[2],nrow(temp2))
colnames(temp2)[4] <- 'Total Assets'
temp2 <- cbind(temp2,quarter)
option <- myBrowser$findElement(using ='xpath','//*[@id="DateDropDown"]/option[3]')
option$clickElement()
doc <- htmlParse(myBrowser$getPageSource()[[1]])
table = readHTMLTable(doc,header=TRUE,as.data.frame = TRUE)
temp3 = table[[3]]
quarter <-  rep(text[3],nrow(temp3))
colnames(temp3)[4] <- 'Total Assets'
temp3 <- cbind(temp3,quarter)
option <- myBrowser$findElement(using ='xpath','//*[@id="DateDropDown"]/option[4]')
option$clickElement()
doc <- htmlParse(myBrowser$getPageSource()[[1]])
table = readHTMLTable(doc,header=TRUE,as.data.frame = TRUE)
temp4 = table[[3]]
quarter <-  rep(text[4],nrow(temp4))
colnames(temp4)[4] <- 'Total Assets'
temp4 <- cbind(temp4,quarter)
option <- myBrowser$findElement(using ='xpath','//*[@id="DateDropDown"]/option[5]')
option$clickElement()
doc <- htmlParse(myBrowser$getPageSource()[[1]])
table = readHTMLTable(doc,header=TRUE,as.data.frame = TRUE)
temp5 = table[[3]]
quarter <-  rep(text[5],nrow(temp5))
colnames(temp5)[4] <- 'Total Assets'
temp5 <- cbind(temp5,quarter)
option <- myBrowser$findElement(using ='xpath','//*[@id="DateDropDown"]/option[6]')
option$clickElement()
doc <- htmlParse(myBrowser$getPageSource()[[1]])
table = readHTMLTable(doc,header=TRUE,as.data.frame = TRUE)
temp6 = table[[3]]
quarter <-  rep(text[6],nrow(temp6))
colnames(temp6)[4] <- 'Total Assets'
temp6 <- cbind(temp6,quarter)
option <- myBrowser$findElement(using ='xpath','//*[@id="DateDropDown"]/option[7]')
option$clickElement()
doc <- htmlParse(myBrowser$getPageSource()[[1]])
table = readHTMLTable(doc,header=TRUE,as.data.frame = TRUE)
temp7 = table[[3]]
quarter <-  rep(text[7],nrow(temp7))
colnames(temp7)[4] <- 'Total Assets'
temp7 <- cbind(temp7,quarter)
option <- myBrowser$findElement(using ='xpath','//*[@id="DateDropDown"]/option[8]')
option$clickElement()
doc <- htmlParse(myBrowser$getPageSource()[[1]])
table = readHTMLTable(doc,header=TRUE,as.data.frame = TRUE)
temp8 = table[[3]]
quarter <-  rep(text[8],nrow(temp8))
colnames(temp8)[4] <- 'Total Assets'
temp8 <- cbind(temp8,quarter)
option <- myBrowser$findElement(using ='xpath','//*[@id="DateDropDown"]/option[9]')
option$clickElement()
doc <- htmlParse(myBrowser$getPageSource()[[1]])
table = readHTMLTable(doc,header=TRUE,as.data.frame = TRUE)
temp9 = table[[3]]
quarter <-  rep(text[9],nrow(temp9))
colnames(temp9)[4] <- 'Total Assets'
temp9 <- cbind(temp9,quarter)
option <- myBrowser$findElement(using ='xpath','//*[@id="DateDropDown"]/option[10]')
option$clickElement()
doc <- htmlParse(myBrowser$getPageSource()[[1]])
table = readHTMLTable(doc,header=TRUE,as.data.frame = TRUE)
temp10 = table[[3]]
quarter <-  rep(text[10],nrow(temp10))
colnames(temp10)[4] <- 'Total Assets'
temp10 <- cbind(temp10,quarter)
option <- myBrowser$findElement(using ='xpath','//*[@id="DateDropDown"]/option[11]')
option$clickElement()
doc <- htmlParse(myBrowser$getPageSource()[[1]])
table = readHTMLTable(doc,header=TRUE,as.data.frame = TRUE)
temp11 = table[[3]]
quarter <-  rep(text[11],nrow(temp11))
colnames(temp11)[4] <- 'Total Assets'
temp11 <- cbind(temp11,quarter)
option <- myBrowser$findElement(using ='xpath','//*[@id="DateDropDown"]/option[12]')
option$clickElement()
doc <- htmlParse(myBrowser$getPageSource()[[1]])
table = readHTMLTable(doc,header=TRUE,as.data.frame = TRUE)
temp12 = table[[3]]
quarter <-  rep(text[12],nrow(temp12))
colnames(temp12)[4] <- 'Total Assets'
temp12 <- cbind(temp12,quarter)
option <- myBrowser$findElement(using ='xpath','//*[@id="DateDropDown"]/option[13]')
option$clickElement()
doc <- htmlParse(myBrowser$getPageSource()[[1]])
table = readHTMLTable(doc,header=TRUE,as.data.frame = TRUE)
temp13 = table[[3]]
quarter <-  rep(text[13],nrow(temp13))
colnames(temp13)[4] <- 'Total Assets'
temp13 <- cbind(temp13,quarter)
option <- myBrowser$findElement(using ='xpath','//*[@id="DateDropDown"]/option[14]')
option$clickElement()
doc <- htmlParse(myBrowser$getPageSource()[[1]])
table = readHTMLTable(doc,header=TRUE,as.data.frame = TRUE)
temp14 = table[[3]]
quarter <-  rep(text[14],nrow(temp14))
colnames(temp14)[4] <- 'Total Assets'
temp14 <- cbind(temp14,quarter)
option <- myBrowser$findElement(using ='xpath','//*[@id="DateDropDown"]/option[15]')
option$clickElement()
doc <- htmlParse(myBrowser$getPageSource()[[1]])
table = readHTMLTable(doc,header=TRUE,as.data.frame = TRUE)
temp15 = table[[3]]
quarter <-  rep(text[15],nrow(temp15))
colnames(temp15)[4] <- 'Total Assets'
temp15 <- cbind(temp15,quarter)
# row binding all the dataframes and creating one csv file 
data_frames <- rbind(temp1, temp2,temp3,temp4, temp5,temp6,temp7,temp8,temp9,temp10,temp11,temp12,temp13,temp14,temp15)
# creating consolidated csv for all options
write.csv(data_frames, 'assignment1_part1_scrape.csv',row.names=FALSE)
# cleaning data
data <- read.csv('assignment1_part1_scrape.csv',header=T,sep=',')
colnames(data) <- c("Rank","Institution Name (RSSD ID)","Location","Total Assets","quarter")
data <- as.data.frame(data)
data_frame <- tidyr::separate(data,"Location",sep=",", c("City","State"))
write.csv(data_frame, 'assignment1_part1_scrape_cleaner.csv',row.names=FALSE)
# creating boxplot
library("outliers")
# reading csv file
d<-read.csv("assignment1_part1_scrape.csv")
# converting factor into numeric values by removing , and $
TotalAsset<-gsub(pattern = ",","",d$Total.Assets)
TotalAsset<-gsub(pattern = "[$]","",TotalAsset)
TotalAsset<-as.numeric(TotalAsset)
boxplot(TotalAsset)