setwd("/Users/hinagandhi/desktop/RAssignment")
install.packages("ghit")
install.packages("rJava")
install.packages("devtools")
devtools::install_github(c("ropenscilabs/tabulizerjars", "ropenscilabs/tabulizer"), args = "--no-multiarch")
install.packages("plyr")
install.packages("pdftools")
library(ghit)
library(rJava)
library(devtools)
library(tabulizer)
library(plyr)
library(pdftools)
library(dplyr)
library(rvest)
library(RSelenium)
library(httr)
library(tidyr)
checkForServer()
startServer()
myBrowser <- remoteDriver(browserName="chrome")
myBrowser$open()
myBrowser$navigate(url)
url<- "https://www.ffiec.gov/nicpubweb/content/BHCPRRPT/BHCPR_Peer.htm"

main.page <- read_html(x = "https://www.ffiec.gov/nicpubweb/content/BHCPRRPT/BHCPR_Peer.htm")

href <- main.page %>% # feed `main.page` to the next step
  html_nodes("a") %>% # get the CSS nodes
  html_attr("href") # extract the URLs

length(href)

num <- grep('PeerGroup_1', href)

links <- href[num]


#extracting the year from the url
extractYear <- function(x){
  substr(x, nchar(x)-7, nchar(x)-4)
}


#extract quarter from the url
extractQuarter <- function(x){
  substr(x, 69, 69)
}

#link for pdf
for(i in 1: length(links)) {
  url[i] <- paste0("https://www.ffiec.gov/nicpubweb/content/BHCPRRPT/", links[i])
  # converting to proper naming format
  year <- extractYear(url[i])
  quarter <- paste0("_Quarter_",extractQuarter(url[i]))
  quarter1<-extractQuarter(url[i])
  if (quarter1=="M" || quarter1=="m")
  {
    quarter=1
  }
  else if(quarter1=="J"|| quarter1=="j"){
    quarter=2
  }
  else if(quarter1=="S" || quarter1=="s"){
    quarter=3
  }
  else if(quarter1=="D" || quarter1=="d"){
    quarter=4
  }
  
  pdfname <- paste0("PeerGroup1_", year, paste0("_",quarter));
  
  pdfname <- download.file(url[i], paste0(pdfname, ".pdf"), mode = "wb")
}
pdf_name = list.files(pattern = "[.]pdf$") 
#extracting the year from the url
extractYear <- function(x){
  substr(x, nchar(x)-9, nchar(x)-6)
}


#extract quarter from the url
extractQuarter <- function(x){
  substr(x, nchar(x)-4, nchar(x)-4)
}

year <- extractYear(pdf_name)
quarter <- paste0("_Quarter_",extractQuarter(pdf_name))

pdfname <- paste0("Peer1_", year, quarter)
for(i in 1:length(pdf_name))
{
  do.call(file.remove, list(list.files(pattern = "pdf[0-9]*.csv", full.names = TRUE)))
  info <- pdf_info(pdf_name[i])
  for(j in 1:info$pages) 
  { 
    write.csv( extract_tables(pdf_name[j], guess = FALSE, pages= j),paste0(j,".csv"),row.names=FALSE)
  }
  file_names = list.files(pattern = "^[1-9]|^[1-9][0-9][.]csv$") 
  file_names <- file_names[order(as.numeric(sub("([0-9]*).*", "\\1", file_names)))]
  # for every name you found go and read the csv with that name 
  # (this creates a list of files)
  import_files = lapply(file_names, read.csv)
  # append those files one after the other (collapse list elements to one dataset) and save it as d
  all_data = do.call(rbind.fill,import_files)
  write.csv(all_data,paste0(pdfname[i],".csv"), na="",row.names=FALSE)
  do.call(file.remove, list(list.files(pattern = "pdf^[0-9]*.csv", full.names = TRUE))) 
}

