install.packages("reshape2")
library(reshape2)
# reading csv file
data <- read.csv(file='assignment1_part1_scrape.csv',header=T,sep=',')
# converting data into data frame
data <- as.data.frame(data)
# reanming column names
colnames(data) <- c('Rank','InstituitionNameRSSDID','Location','TotalAssets','quarter')
# melting data by ids 
mdata <- melt(data, id=c("Rank","Location","TotalAssets","quarter"))
# Unstacking the data and showing columns in x axis and value + Location + Rank + TotalAssets in y axis
data_frame <- dcast(mdata,value + Location + Rank + TotalAssets ~ quarter, fun.aggregate = length )
View(data_frame)
# renaming ccolumn name
colnames(data_frame)[1] <- "Instituition Name (RSSDID)"
# writing csv file
write.csv(data_frame, 'reshape_unstacked.csv',row.names=FALSE)
# Stacking the unstacked data by using melt function
data <- melt(data_frame, id=c('Instituition Name (RSSDID)','Location','Rank','TotalAssets'))
# removing value column having value as 0
data <- data[data$value==1,]
# to make it stacked removing column value
data$value <- NULL
# renaming last column as quarter
colnames(data)[5] <- "Quarter"
# writing csv file
write.csv(data, '/Users/hinagandhi/desktop/reshape_stacked.csv',row.names=FALSE)
